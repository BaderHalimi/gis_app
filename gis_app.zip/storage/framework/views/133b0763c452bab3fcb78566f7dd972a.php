
<div <?php echo e($attributes->class('flex')); ?> data-flux-breadcrumbs>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\hp\Documents\laravel\gis_app\vendor\livewire\flux\stubs\resources\views\flux\breadcrumbs\index.blade.php ENDPATH**/ ?>