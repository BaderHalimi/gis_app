
<div <?php echo e($attributes->class('text-sm')); ?> data-slot="text">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\hp\Documents\laravel\gis_app\vendor\livewire\flux\stubs\resources\views\flux\callout\text.blade.php ENDPATH**/ ?>