<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => __('Dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Dashboard'))]); ?>
    <div class="flex h-full w-full flex-1 flex-col gap-4 rounded-xl p-6">
        <div class="grid auto-rows-min gap-4 md:grid-cols-3" style="margin-bottom: 1rem;">
            <div class="relative overflow-hidden">
                
                <h1 class="text-2xl font-bold text-black dark:text-white"><?php echo e(__('Stations')); ?></h1>
            </div>
            <div class="relative overflow-hidden">
                
            </div>
            <div class="relative overflow-hidden">
                <div class="flex justify-end">

                    
                    <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['color' => 'primary','icon' => 'plus','href' => route('stations.create'),'wire:navigate' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'primary','icon' => 'plus','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('stations.create')),'wire:navigate' => true]); ?>
                        <?php echo e(__('Add Station')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>

                    
                </div>
            </div>
        </div>
        <div class="relative h-full flex-1 overflow-hidden">
            
            <div class="overflow-x-auto rounded-lg">
                <table style="width: 100%;" class="min-w-full w-100 divide-y divide-gray-200 dark:divide-gray-700">
                    <thead class="bg-gray-100 dark:bg-gray-800">
                        <tr>
                            <th
                                class="px-6 py-3 text-center text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase">
                                #</th>
                            <th
                                class="px-6 py-3 text-center text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase">
                                Name</th>
                            <th
                                class="px-6 py-3 text-center text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase">
                                Type</th>
                            <th
                                class="px-6 py-3 text-center text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase">
                                Latitude</th>
                            <th
                                class="px-6 py-3 text-center text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase">
                                Longitude</th>
                            <th
                                class="px-6 py-3 text-center text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase">
                                Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 dark:divide-gray-800">
                        <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr
                                class="hover:bg-gray-50 dark:hover:bg-gray-800 transition border-b dark:border-gray-200">
                                <td style="padding:0.5rem 0;"
                                    class="px-6 text-center font-semibold py-4 text-sm text-gray-800 dark:text-gray-200">
                                    <?php echo e($station->id); ?></td>
                                <td style="padding:0.5rem 0;"
                                    class="px-6 text-center font-semibold py-4 text-sm text-gray-800 dark:text-gray-200">
                                    <?php echo e($station->name); ?></td>
                                <td style="padding:0.5rem 0;" class="px-6 text-center font-semibold py-4 text-sm">
                                    <span
                                        class="inline-block px-2 py-1 text-xs font-medium rounded-full
                                        <?php if($station->type === 'gas'): ?> bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300
                                        <?php elseif($station->type === 'petrol'): ?> bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300
                                        <?php elseif($station->type === 'fire'): ?> bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300
                                        <?php else: ?> bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300 <?php endif; ?>">
                                        <?php echo e($station->type); ?>

                                    </span>
                                </td>
                                <td style="padding:0.5rem 0;"
                                    class="px-6 text-center font-semibold py-4 text-sm text-gray-800 dark:text-gray-200">
                                    <?php echo e($station->lat); ?></td>
                                <td style="padding:0.5rem 0;"
                                    class="px-6 text-center font-semibold py-4 text-sm text-gray-800 dark:text-gray-200">
                                    <?php echo e($station->lng); ?></td>
                                <td style="padding:0.5rem 0;" class="px-6 text-center font-semibold py-4 space-x-2">
                                    <a href="<?php echo e(route('stations.show', $station)); ?>"
                                        class="inline-block px-3 py-1 bg-blue-500 hover:bg-blue-600 text-white text-sm rounded-lg shadow">View</a>
                                    <a href="<?php echo e(route('stations.edit', $station)); ?>"
                                        class="inline-block px-3 py-1 bg-yellow-500 hover:bg-yellow-600 text-white text-sm rounded-lg shadow">Edit</a>
                                    <form id="delete-form-<?php echo e($station->id); ?>"
                                        action="<?php echo e(route('stations.destroy', $station)); ?>" method="POST"
                                        class="inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" onclick="confirmDelete(<?php echo e($station->id); ?>)"
                                            class="px-3 py-1 bg-red-500 hover:bg-red-600 text-white text-sm rounded-lg shadow">
                                            Delete
                                        </button>
                                    </form>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="mt-2">
                    <?php echo e($stations->links()); ?>

                </div>
            </div>

        </div>
    </div>
    <script>
        function confirmDelete(stationId) {
            Swal.fire({
                title: 'هل أنت متأكد؟',
                text: "لا يمكنك التراجع بعد الحذف!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف!',
                cancelButtonText: 'إلغاء'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById(`delete-form-${stationId}`).submit();
                }
            });
        }
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\Users\hp\Documents\laravel\gis_app\resources\views\stations.blade.php ENDPATH**/ ?>